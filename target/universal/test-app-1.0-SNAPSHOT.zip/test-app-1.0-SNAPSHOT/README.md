# shs-platform-play
# test app for deploying to EC2

